// src/app/data.ts

// 言語の型を定義
export type Language = 'ja' | 'en' | 'zh';

// メニュー情報の型を定義
export type Member = {
  id: string;
  name: string;
  description: string;
  image: string;
  // --- 絞り込みと並び替えに使用する属性 ---
  category: 'Ramen' | 'SideDish' | 'Drink' | 'Topping'; // 料理ジャンル
  isVegan: boolean; // ヴィーガン
  popularity: number; // 人気順 (1〜10, 10が最高)
  allergy: ('egg' | 'wheat' | 'soy')[]; // アレルギー
  // ------------------
};

// データ本体
export const menuData: Record<Language, Member[]> = {
  ja: [
    { 
      id: '0001', 
      name: '醤油ラーメン', 
      description: '鶏ガラベースのあっさりとした定番の味です。', 
      image: '/images/shoyu.jpg',
      category: 'Ramen', 
      isVegan: false, 
      popularity: 8, 
      allergy: ['wheat', 'soy'] 
    },
    { 
      id: '0002', 
      name: '塩ラーメン', 
      description: '透き通ったスープと、魚介の旨味が特徴です。', 
      image: '/images/shio.jpg',
      category: 'Ramen', 
      isVegan: false, 
      popularity: 9, 
      allergy: ['wheat'] 
    },
    { 
      id: '0003', 
      name: '味噌ラーメン', 
      description: '濃厚な味噌と香味野菜のパンチが効いた一杯。', 
      image: '/images/miso.jpg',
      category: 'Ramen', 
      isVegan: false, 
      popularity: 10, 
      allergy: ['wheat', 'soy'] 
    },
    { 
      id: '0004', 
      name: '餃子', 
      description: 'パリパリの皮とジューシーな肉汁。', 
      image: '/images/gyoza.jpg',
      category: 'SideDish', 
      isVegan: false, 
      popularity: 7, 
      allergy: ['wheat', 'soy'] 
    },
    { 
      id: '0005', 
      name: 'チャーハン', 
      description: '強火で一気に仕上げた、パラパラの本格チャーハン。', 
      image: '/images/friedrice.jpg', 
      category: 'SideDish', 
      isVegan: false, 
      popularity: 8, 
      allergy: ['egg', 'soy'] 
    },
    { 
      id: '0006', 
      name: 'チャーシュー丼', 
      description: '特製ダレで煮込んだ柔らかチャーシューがたっぷり。', 
      image: '/images/don.jpg', 
      category: 'SideDish', 
      isVegan: false, 
      popularity: 7, 
      allergy: ['wheat', 'soy'] 
    },
    { 
      id: '0007', 
      name: 'コーラ', 
      description: 'キンキンに冷えてます。', 
      image: '/images/cola.jpg', 
      category: 'Drink', 
      isVegan: true, 
      popularity: 5, 
      allergy: [] 
    },
    { 
      id: '0008', 
      name: 'オレンジジュース', 
      description: '果汁100%です。', 
      image: '/images/orange.jpg', 
      category: 'Drink', 
      isVegan: true, 
      popularity: 6, 
      allergy: [] 
    },
    { 
      id: '0009', 
      name: 'メロンソーダ', 
      description: '懐かしの味。', 
      image: '/images/soda.jpg', 
      category: 'Drink', 
      isVegan: true, 
      popularity: 5, 
      allergy: [] 
    },
    { 
      id: '0010', 
      name: '味玉', 
      description: '特製のタレに一晩漬け込んだ、とろとろの半熟味玉。', 
      image: '/images/egg.jpg', 
      category: 'Topping', 
      isVegan: false, 
      popularity: 9, 
      allergy: ['egg', 'soy'] 
    },
    // --- ★今回追加したメニュー（日本語）---
    { 
      id: '0011', 
      name: 'もやしラーメン', 
      description: '鶏・豚不使用。自家製ベジブロスともやしが主役のヘルシーな一杯。', 
      image: '/images/moyashi.jpg', 
      category: 'Ramen', 
      isVegan: true, 
      popularity: 7, 
      allergy: ['wheat', 'soy'] 
    },
    { 
      id: '0012', 
      name: '野菜味噌ラーメン', 
      description: '鶏・豚不使用の野菜だしと、まろやかな豆乳味噌仕立て。', 
      image: '/images/vegimiso.jpg', 
      category: 'Ramen', 
      isVegan: true, 
      popularity: 9, 
      allergy: ['wheat', 'soy'] 
    },
    { 
      id: '0013', 
      name: 'ウーロン茶', 
      description: 'さっぱりとした口当たりの定番茶葉。', 
      image: '/images/oolong.jpg', 
      category: 'Drink', 
      isVegan: true, 
      popularity: 6, 
      allergy: [] 
    },
    // ----------------------------------------
  ],
  en: [
    { 
      id: '0001', 
      name: 'Soy Sauce Ramen', 
      description: 'A classic, light taste based on chicken broth.', 
      image: '/images/shoyu.jpg',
      category: 'Ramen', 
      isVegan: false, 
      popularity: 8, 
      allergy: ['wheat', 'soy'] 
    },
    { 
      id: '0002', 
      name: 'Salt Ramen', 
      description: 'Features a clear broth and the rich umami of seafood.', 
      image: '/images/shio.jpg',
      category: 'Ramen', 
      isVegan: false, 
      popularity: 9, 
      allergy: ['wheat'] 
    },
    { 
      id: '0003', 
      name: 'Miso Ramen', 
      description: 'A bold bowl with rich miso and the punch of aromatic vegetables.', 
      image: '/images/miso.jpg',
      category: 'Ramen', 
      isVegan: false, 
      popularity: 10, 
      allergy: ['wheat', 'soy'] 
    },
    { 
      id: '0004', 
      name: 'Gyoza', 
      description: 'Crispy skin and juicy meat filling.', 
      image: '/images/gyoza.jpg',
      category: 'SideDish', 
      isVegan: false, 
      popularity: 7, 
      allergy: ['wheat', 'soy'] 
    },
    { 
      id: '0005', 
      name: 'Fried Rice', 
      description: 'Authentic fried rice, quickly finished over high heat.', 
      image: '/images/friedrice.jpg', 
      category: 'SideDish', 
      isVegan: false, 
      popularity: 8, 
      allergy: ['egg', 'soy'] 
    },
    { 
      id: '0006', 
      name: 'Roasted Pork Bowl', 
      description: 'Topped with plenty of tender pork simmered in special sauce.', 
      image: '/images/don.jpg', 
      category: 'SideDish', 
      isVegan: false, 
      popularity: 7, 
      allergy: ['wheat', 'soy'] 
    },
    { 
      id: '0007', 
      name: 'Cola', 
      description: 'Ice cold.', 
      image: '/images/cola.jpg', 
      category: 'Drink', 
      isVegan: true, 
      popularity: 5, 
      allergy: [] 
    },
    { 
      id: '0008', 
      name: 'Orange Juice', 
      description: '100% fruit juice.', 
      image: '/images/orange.jpg', 
      category: 'Drink', 
      isVegan: true, 
      popularity: 6, 
      allergy: [] 
    },
    { 
      id: '0009', 
      name: 'Melon Soda', 
      description: 'A nostalgic taste.', 
      image: '/images/soda.jpg', 
      category: 'Drink', 
      isVegan: true, 
      popularity: 5, 
      allergy: [] 
    },
    { 
      id: '0010', 
      name: 'Seasoned Egg', 
      description: 'Soft-boiled egg marinated overnight in special sauce.', 
      image: '/images/egg.jpg', 
      category: 'Topping', 
      isVegan: false, 
      popularity: 9, 
      allergy: ['egg', 'soy'] 
    },
    // --- ★今回追加したメニュー（英語）---
    { 
      id: '0011', 
      name: 'Bean Sprout Ramen', 
      description: 'Chicken/Pork-free. A healthy bowl featuring homemade veggie broth and bean sprouts.', 
      image: '/images/moyashi.jpg', 
      category: 'Ramen', 
      isVegan: true, 
      popularity: 7, 
      allergy: ['wheat', 'soy'] 
    },
    { 
      id: '0012', 
      name: 'Vegetable Miso Ramen', 
      description: 'Made with chicken/pork-free vegetable broth and mild soy milk miso.', 
      image: '/images/vegimiso.jpg', 
      category: 'Ramen', 
      isVegan: true, 
      popularity: 9, 
      allergy: ['wheat', 'soy'] 
    },
    { 
      id: '0013', 
      name: 'Oolong Tea', 
      description: 'A standard tea with a refreshing taste.', 
      image: '/images/oolong.jpg', 
      category: 'Drink', 
      isVegan: true, 
      popularity: 6, 
      allergy: [] 
    },
    // ----------------------------------------
  ],
  zh: [
    { 
      id: '0001', 
      name: '酱油拉面', 
      description: '以鸡骨为基础的清淡经典口味。', 
      image: '/images/shoyu.jpg',
      category: 'Ramen', 
      isVegan: false, 
      popularity: 8, 
      allergy: ['wheat', 'soy'] 
    },
    { 
      id: '0002', 
      name: '盐味拉面', 
      description: '清澈的汤头，具有海鲜的鲜味。', 
      image: '/images/shio.jpg',
      category: 'Ramen', 
      isVegan: false, 
      popularity: 9, 
      allergy: ['wheat'] 
    },
    { 
      id: '0003', 
      name: '味噌拉面', 
      description: '浓郁的味噌和香料蔬菜的冲击感。', 
      image: '/images/miso.jpg',
      category: 'Ramen', 
      isVegan: false, 
      popularity: 10, 
      allergy: ['wheat', 'soy'] 
    },
    { 
      id: '0004', 
      name: '饺子', 
      description: '外皮酥脆，肉汁丰富。', 
      image: '/images/gyoza.jpg',
      category: 'SideDish', 
      isVegan: false, 
      popularity: 7, 
      allergy: ['wheat', 'soy'] 
    },
    { 
      id: '0005', 
      name: '炒饭', 
      description: '用大火快速制作的正宗炒饭。', 
      image: '/images/friedrice.jpg', 
      category: 'SideDish', 
      isVegan: false, 
      popularity: 8, 
      allergy: ['egg', 'soy'] 
    },
    { 
      id: '0006', 
      name: '叉烧饭', 
      description: '淋上特制酱汁慢炖的软嫩叉烧。', 
      image: '/images/don.jpg', 
      category: 'SideDish', 
      isVegan: false, 
      popularity: 7, 
      allergy: ['wheat', 'soy'] 
    },
    { 
      id: '0007', 
      name: '可乐', 
      description: '冰镇。', 
      image: '/images/cola.jpg', 
      category: 'Drink', 
      isVegan: true, 
      popularity: 5, 
      allergy: [] 
    },
    { 
      id: '0008', 
      name: '橙汁', 
      description: '100%果汁。', 
      image: '/images/orange.jpg', 
      category: 'Drink', 
      isVegan: true, 
      popularity: 6, 
      allergy: [] 
    },
    { 
      id: '0009', 
      name: '甜瓜苏打', 
      description: '怀旧的味道。', 
      image: '/images/soda.jpg', 
      category: 'Drink', 
      isVegan: true, 
      popularity: 5, 
      allergy: [] 
    },
    { 
      id: '0010', 
      name: '溏心蛋', 
      description: '浸泡在特制酱汁中过夜的半熟鸡蛋。', 
      image: '/images/egg.jpg', 
      category: 'Topping', 
      isVegan: false, 
      popularity: 9, 
      allergy: ['egg', 'soy'] 
    },
    // --- ★今回追加したメニュー（中国語）---
    { 
      id: '0011', 
      name: '豆芽拉面', 
      description: '不含鸡肉/猪肉。以自制素食高汤和豆芽为主的健康拉面。', 
      image: '/images/moyashi.jpg', 
      category: 'Ramen', 
      isVegan: true, 
      popularity: 7, 
      allergy: ['wheat', 'soy'] 
    },
    { 
      id: '0012', 
      name: '蔬菜味噌拉面', 
      description: '使用不含鸡肉/猪肉的蔬菜高汤和温和的豆奶味噌制成。', 
      image: '/images/vegimiso.jpg', 
      category: 'Ramen', 
      isVegan: true, 
      popularity: 9, 
      allergy: ['wheat', 'soy'] 
    },
    { 
      id: '0013', 
      name: '乌龙茶', 
      description: '清爽口感的经典茶饮。', 
      image: '/images/oolong.jpg', 
      category: 'Drink', 
      isVegan: true, 
      popularity: 6, 
      allergy: [] 
    },
    // ----------------------------------------
  ],
};