import Link from 'next/link';
import { menuData, type Language } from '../../data';

type Props = {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ lang?: string }>;
};

export default async function MenuDetailPage({ params, searchParams }: Props) {
  const { id } = await params;
  const { lang } = await searchParams;

  // 言語を判定（デフォルトは日本語）
  const currentLang = (lang === 'en' || lang === 'zh' ? lang : 'ja') as Language;
  
  // 該当する言語のデータリストを取得
  const dataList = menuData[currentLang];
  if (!dataList) {
     return <div>Data Error</div>;
  }

  // 商品を検索
  const member = dataList.find(m => m.id === id);

  // テキスト定義
  const backText = currentLang === 'ja' ? '一覧に戻る' : currentLang === 'zh' ? '返回列表' : 'Back to List';
  const notFoundText = currentLang === 'ja' ? '商品が見つかりません' : 'Item not found';

  if (!member) {
    return (
      <div style={{ color: 'white', padding: '40px', textAlign: 'center' }}>
        <h1>{notFoundText}</h1>
        <div style={{ marginTop: '20px' }}>
          <Link href={`/?lang=${currentLang}`} style={{ color: '#3b82f6' }}>{backText}</Link>
        </div>
      </div>
    );
  }

  return (
    <div style={{ 
      maxWidth: '800px', 
      margin: '40px auto', 
      padding: '24px',
      backgroundColor: '#3b0808ff', 
      color: '#fff',
      borderRadius: '16px',
      boxShadow: '0 4px 20px rgba(0,0,0,0.5)'
    }}>
      
      {/* 戻るボタン: 言語を維持して戻る */}
      <div style={{ marginBottom: '20px' }}>
        <Link 
          href={`/?lang=${currentLang}`} 
          style={{ color: '#aaa', textDecoration: 'none' }}
        >
            &lt; {backText}
        </Link>
      </div>

      <div style={{ 
        width: '100%', 
        height: '400px', 
        backgroundColor: '#222', 
        borderRadius: '12px', 
        overflow: 'hidden', 
        marginBottom: '32px',
        border: '1px solid #333'
      }}>
        <img 
          src={member.image} 
          alt={member.name} 
          style={{ width: '100%', height: '100%', objectFit: 'cover' }} 
        />
      </div>
      
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '16px' }}>
        <h1 style={{ fontSize: '2.5rem', fontWeight: 'bold', margin: 0 }}>
          {member.name}
        </h1>
        {/* 価格表示エリア */}
        <div style={{ 
          fontSize: '2rem', 
          color: '#d4af37', 
          fontWeight: 'bold', 
          fontFamily: 'serif',
          textShadow: '0 2px 4px rgba(0,0,0,0.5)'
        }}>
          ¥{member.price ? member.price.toLocaleString() : '-'}
        </div>
      </div>
      
      <p style={{ color: '#888', marginBottom: '24px', fontFamily: 'monospace' }}>
        ID: {member.id}
      </p>
      
      <div style={{ fontSize: '1.1rem', lineHeight: '1.8', color: '#ddd', borderTop: '1px solid #333', paddingTop: '24px' }}>
        {member.description}
      </div>

    </div>
  );
}