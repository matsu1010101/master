"use client";

import { useState, useEffect, Suspense, useMemo } from 'react';
import { useSearchParams } from 'next/navigation';
import MemberList from './MemberLists';
import { menuData, type Language, type Member } from './data';

// --- 絞り込みと並び替えのための型定義 ---
type FilterType = 'all' | 'vegan' | 'ramen' | 'sidedish' | 'drink' | 'topping' | 'allergy-wheat';
type SortType = 'default' | 'popularity' | 'category';


// コンテンツ部分
function RamenShopContent() {
  const searchParams = useSearchParams();
  const langParam = searchParams.get('lang');

  const [language, setLanguage] = useState<Language | null>(null);
  // 絞り込みの状態管理
  const [filter, setFilter] = useState<FilterType>('all');
  // 並び替えの状態管理
  const [sort, setSort] = useState<SortType>('default');

  // URLパラメータがあれば言語を設定
  useEffect(() => {
    if (langParam === 'ja' || langParam === 'en' || langParam === 'zh') {
      setLanguage(langParam as Language);
    }
  }, [langParam]);

  // フィルタリングとソートのロジック (useMemoで実行)
  const filteredAndSortedMembers = useMemo(() => {
    if (!language) return [];

    let currentMembers = [...menuData[language]]; // 元データをコピーして操作

    // 1. フィルタリング (絞り込み)
    if (filter === 'vegan') {
      // 絞り込み：ヴィーガン
      currentMembers = currentMembers.filter(m => m.isVegan);
    } else if (filter === 'ramen') {
      // 絞り込み：ジャンル（ラーメン）
      currentMembers = currentMembers.filter(m => m.category === 'Ramen');
    } else if (filter === 'sidedish') {
      // 絞り込み：ジャンル（サイドディッシュ）
      currentMembers = currentMembers.filter(m => m.category === 'SideDish');
    } else if (filter === 'drink') {
      // 絞り込み：ジャンル（ドリンク）
      currentMembers = currentMembers.filter(m => m.category === 'Drink');
    } else if (filter === 'topping') {
      // 絞り込み：ジャンル（トッピング）
      currentMembers = currentMembers.filter(m => m.category === 'Topping');
    } else if (filter === 'allergy-wheat') {
      // 絞り込み：アレルギー（小麦不使用）
      currentMembers = currentMembers.filter(m => !m.allergy.includes('wheat'));
    }

    // 2. ソート (並び替え)
    if (sort === 'popularity') {
      // 並び替え：人気順（降順）
      currentMembers.sort((a, b) => b.popularity - a.popularity);
    } else if (sort === 'category') {
      // 並び替え：ジャンル別
      // category（Ramen, SideDish, Topping, Drink）の順に並べる
      const categoryOrder: Member['category'][] = ['Ramen', 'SideDish', 'Topping', 'Drink'];
      currentMembers.sort((a, b) => categoryOrder.indexOf(a.category) - categoryOrder.indexOf(b.category));
    }

    return currentMembers;
  }, [language, filter, sort]);


  // テキスト定義 (UIに表示する多言語テキスト)
  const texts = {
    ja: {
      filterTitle: '絞り込み',
      filterAll: 'すべて',
      filterVegan: 'ヴィーガン',
      filterRamen: 'ラーメン',
      filterSideDish: 'サイド',
      filterDrink: 'ドリンク',
      filterTopping: 'トッピング',
      filterNoWheat: '小麦不使用',
      sortTitle: '並び替え',
      sortDefault: '標準',
      sortPopularity: '人気順',
      sortCategory: 'ジャンル別',
    },
    en: {
      filterTitle: 'Filter',
      filterAll: 'All',
      filterVegan: 'Vegan',
      filterRamen: 'Ramen',
      filterSideDish: 'Side Dish',
      filterDrink: 'Drink',
      filterTopping: 'Topping',
      filterNoWheat: 'Wheat-Free',
      sortTitle: 'Sort',
      sortDefault: 'Default',
      sortPopularity: 'Popularity',
      sortCategory: 'Category',
    },
    zh: {
      filterTitle: '筛选',
      filterAll: '全部',
      filterVegan: '素食',
      filterRamen: '拉面',
      filterSideDish: '小吃',
      filterDrink: '饮料',
      filterTopping: '配菜',
      filterNoWheat: '不含小麦',
      sortTitle: '排序',
      sortDefault: '标准',
      sortPopularity: '人气',
      sortCategory: '按种类',
    }
  };


  // 言語未選択時
  if (!language) {
    return (
      <main style={styles.container}>
        <h1 style={styles.title}>Welcome to Ramen Hikari</h1>
        <div style={styles.subtitle}>Please select your language</div>
        
        <div style={styles.buttonGroup}>
          <button onClick={() => setLanguage('ja')} style={styles.langButton}>日本語</button>
          <button onClick={() => setLanguage('en')} style={styles.langButton}>English</button>
          <button onClick={() => setLanguage('zh')} style={styles.langButton}>中文</button>
        </div>
      </main>
    );
  }

  const currentTexts = texts[language];

  // 言語選択後 (メイン画面)
  return (
    <main>
      <div style={{ padding: '20px 0 0 20px' }}>
        <button onClick={() => setLanguage(null)} style={styles.backButton}>
          ← Language Select
        </button>
      </div>

      <div style={styles.controlsContainer}>
        {/* 絞り込み UI */}
        <div style={styles.controlGroup}>
          <span style={styles.controlTitle}>{currentTexts.filterTitle}:</span>
          
          {/* すべて */}
          <button 
            onClick={() => setFilter('all')} 
            style={filter === 'all' ? styles.activeControl : styles.controlButton}
          >
            {currentTexts.filterAll}
          </button>
          
          {/* ヴィーガン */}
          <button 
            onClick={() => setFilter('vegan')} 
            style={filter === 'vegan' ? styles.activeControl : styles.controlButton}
          >
            {currentTexts.filterVegan}
          </button>

          {/* ジャンル絞り込み (ラーメン) */}
          <button 
            onClick={() => setFilter('ramen')} 
            style={filter === 'ramen' ? styles.activeControl : styles.controlButton}
          >
            {currentTexts.filterRamen}
          </button>

          {/* ジャンル絞り込み (サイド) */}
          <button 
            onClick={() => setFilter('sidedish')} 
            style={filter === 'sidedish' ? styles.activeControl : styles.controlButton}
          >
            {currentTexts.filterSideDish}
          </button>
          
          {/* ジャンル絞り込み (ドリンク) */}
          <button 
            onClick={() => setFilter('drink')} 
            style={filter === 'drink' ? styles.activeControl : styles.controlButton}
          >
            {currentTexts.filterDrink}
          </button>
          
          {/* ジャンル絞り込み (トッピング) */}
          <button 
            onClick={() => setFilter('topping')} 
            style={filter === 'topping' ? styles.activeControl : styles.controlButton}
          >
            {currentTexts.filterTopping}
          </button>


           {/* アレルギー絞り込み (小麦不使用) */}
           <button 
            onClick={() => setFilter('allergy-wheat')} 
            style={filter === 'allergy-wheat' ? styles.activeControl : styles.controlButton}
          >
            {currentTexts.filterNoWheat}
          </button>
        </div>

        {/* 並び替え UI */}
        <div style={styles.controlGroup}>
          <span style={styles.controlTitle}>{currentTexts.sortTitle}:</span>
          
          {/* 標準 */}
          <button 
            onClick={() => setSort('default')} 
            style={sort === 'default' ? styles.activeControl : styles.controlButton}
          >
            {currentTexts.sortDefault}
          </button>
          
          {/* 人気順並び替え */}
          <button 
            onClick={() => setSort('popularity')} 
            style={sort === 'popularity' ? styles.activeControl : styles.controlButton}
          >
            {currentTexts.sortPopularity}
          </button>
          
          {/* ジャンル別並び替え */}
           <button 
            onClick={() => setSort('category')} 
            style={sort === 'category' ? styles.activeControl : styles.controlButton}
          >
            {currentTexts.sortCategory}
          </button>
        </div>
      </div>

      {/* フィルタリング・ソート済みのデータを渡す */}
      <MemberList members={filteredAndSortedMembers} lang={language} />
    </main>
  );
}

// メインコンポーネント
export default function Page() {
  return (
    <Suspense fallback={<div style={{color: '#fff', textAlign: 'center', marginTop: '50px'}}>Loading...</div>}>
      <RamenShopContent />
    </Suspense>
  );
}

// スタイル (これまでのやり取りで使用されたダークモードのスタイル)
const styles = {
  container: {
    height: '100vh',
    display: 'flex',
    flexDirection: 'column' as const,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#111',
    color: '#fff',
  },
  title: {
    fontSize: '2.5rem',
    fontWeight: 'bold',
    marginBottom: '10px',
  },
  subtitle: {
    color: '#aaa',
    marginBottom: '40px',
  },
  buttonGroup: {
    display: 'flex',
    gap: '20px',
    flexDirection: 'column' as const,
  },
  langButton: {
    padding: '15px 40px',
    fontSize: '1.2rem',
    fontWeight: 'bold',
    borderRadius: '50px',
    cursor: 'pointer',
    backgroundColor: '#333',
    color: '#fff',
    border: '1px solid #555',
    transition: '0.2s',
    width: '200px',
  },
  backButton: {
    background: 'none',
    border: 'none',
    color: '#888',
    cursor: 'pointer',
    fontSize: '1rem',
    textDecoration: 'underline',
  },
  // コントロールコンテナ
  controlsContainer: {
    margin: '20px auto',
    padding: '20px',
    maxWidth: '700px',
    backgroundColor: '#1a1a1a',
    borderRadius: '8px',
    border: '1px solid #333',
  },
  // 絞り込み/並び替えグループ
  controlGroup: {
    display: 'flex',
    flexWrap: 'wrap' as const,
    gap: '10px',
    marginBottom: '15px',
    alignItems: 'center',
  },
  // タイトル
  controlTitle: {
    color: '#ccc',
    fontWeight: 'bold',
    marginRight: '10px',
    fontSize: '1rem',
    flexShrink: 0, 
  },
  // コントロールボタン (非アクティブ)
  controlButton: {
    padding: '8px 15px',
    border: '1px solid #555',
    borderRadius: '20px',
    backgroundColor: '#333',
    color: '#fff',
    cursor: 'pointer',
    fontSize: '0.9rem',
    transition: 'background-color 0.2s, border-color 0.2s',
  },
  // アクティブなコントロールボタン
  activeControl: {
    padding: '8px 15px',
    border: '1px solid #3b82f6',
    borderRadius: '20px',
    backgroundColor: '#3b82f6',
    color: '#fff',
    cursor: 'pointer',
    fontSize: '0.9rem',
  },
};